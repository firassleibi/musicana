<?php
//echo date("m");
echo "1";
?>